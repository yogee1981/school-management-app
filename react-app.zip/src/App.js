import React, { Component } from 'react';
//import { BrowserRouter as Router, Route, Link } from "react-router-dom";
//import { Router, Route, Switch } from 'react-router';
//import { Link } from 'react-router';
import logo from './img/logo.png';
import './bootstrap.css';
import './custom.css';

class App extends Component {
  render() {
    return (
      <div className="container">        
        <div className="row">
        <div className="col-12">
        <p className="text-center mt-5 text-primary"><img src={logo} alt="logo" width="100" /></p>
        <h4 className="text-white text-center font-weight-normal">School Management App</h4>
        </div>
          <div className="col-md-4"></div>
          <div className="col-md-4 bg-light mt-3 login-box">
            <h4 className="text-center">Teacher Login!</h4>

            <form>
              <p className="mb-1">Email Address:</p>
              <input type="email" name="email" className="form-control" placeholder="Enter email" required />
              <p className="mb-1 mt-2">Password:</p>
              <input type="password" name="password" className="form-control" placeholder="Enter password" required />
              <p className="text-center mt-2">By signing up you accept our <a href="./terms-of-use">Terms Of Use</a></p>
              <p></p>
              <input type="submit" value="Login" className="btn btn-primary form-control" />
              <input type="button" value="Forgot Password" className="btn btn-outline-secondary form-control mt-2" />
              <p className="text-center mt-2">Don't have account? <a href="./sign-up">Sign up here</a></p>
            </form>

          </div>
          <div className="col-md-4"></div>
        </div>
      </div>
      /*
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
      */
    );
  }
}

export default App;
